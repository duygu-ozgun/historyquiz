public class QuizBook {
    public static String[] question = new String[] {
            "Mustafa Kemal'in ilk görev yeri Şam'dır."
            "Trablusgarb Cephesinde Osmanlı Devleti Fransa ile savaşmıştır."
            "İngiltere I.Dünya Savaşı İtilaf Devletlerindendir."
            "Göktürk Türk adıyla kurulmuş ilk Türk Devletidir."
            "Selçuklular Devletinin kurucusu Selçuklulardır."
            "Sultan Alparslan Selçuklular Devletinin Yöneticisidir."
            "Fatih Sultan Mehmet Yavuz Sultan Selim'in dedesidir."
            "Türklerin kullandığı ilk alfabe Uygur Alfabesidir."
            "Sakalar Maniehizm inancına sahip Türk Topluluğudur."
    };
    public static boolean[] answer = new boolean[] {
            true,false,true,true,false,true,true,false,false
    };


}
